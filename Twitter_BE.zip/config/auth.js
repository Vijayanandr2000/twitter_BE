module.exports = {
    secretKey: 'secretKeysecretKey'
}