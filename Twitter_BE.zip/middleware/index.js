const authJwt = require('./authVerify'); 


module.exports = {
    authJwt
}